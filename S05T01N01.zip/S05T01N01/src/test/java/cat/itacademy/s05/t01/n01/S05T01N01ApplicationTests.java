package cat.itacademy.s05.t01.n01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S05T01N01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
