package cat.itacademy.s05.t01.n01.model;

import org.springframework.data.mongodb.core.mapping.Document;


public class Card {
    private String suit;
    private String rank;
}
